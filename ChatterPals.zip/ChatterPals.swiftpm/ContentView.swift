import SwiftUI

struct pair{
    var x : CGFloat
    var y : CGFloat
    
    init(x: CGFloat, y: CGFloat) {
        self.x = x
        self.y = y
    }
}

struct ContentView: View {
    @State var viewnumber = 0;  
    
    @State var list1   = [pair(x: 100, y: 300),pair(x: 150, y: 500),pair(x: 50, y: 300),pair(x: -150, y: 10),pair(x: 150, y: 450),pair(x: 150, y: -300),pair(x: -100, y: -100),pair(x: 0, y: 0),pair(x: -150, y: -700)]
    @State var basket = []
    
    func  randomnGenerator(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            
            for i in 0...8{
                let w = Double.random(in: -180...180)
                let h = Double.random(in: -450...450)
                list1[i].x=w
                list1[i].y=h
            }
            randomnGenerator()
        }
    }
    
    
    func changeviewToApple(){
        print("hii")
        viewnumber = 1 
    }
    
    func changeviewToOrange(){
        viewnumber = 2
    }
    func changeviewToGrapes(){
        viewnumber = 3
    }
    var body: some View {
    
        if viewnumber==0 {
            ZStack{
                VStack {
                    
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    
                    
                    
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    
                    
                    
                    
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    
                   
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    HStack{
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        Image("image 4").padding(.horizontal,30)
                        
                    }.padding(.vertical,10)
                    
                }.background(Color(red:0.6,green:0.9,blue:0.3,opacity: 1))
                ZStack{
                    Text("ChatterPals").font(.system(size: 44)).fontWeight(.heavy).foregroundStyle(Color.white).shadow(radius: 50)
                
                }
                VStack{
                    Button(action: {
                        
                        changeviewToApple()
                    }) {
                        Image("apple").resizable().frame(width: 50,height: 50)
                    }.offset(x : list1[0].x,y : list1[0].y).padding(.all,10)
                    Button(action: {
                        changeviewToApple()          }) {
                        Image("apple").resizable().frame(width: 50,height: 50)
                    }.offset(x : list1[1].x,y : list1[1].y).padding(.all,10)
                    Button(action: {
                        changeviewToApple()
                    }) {
                        Image("apple").resizable().frame(width: 50,height: 50)
                    }.offset(x : list1[2].x,y : list1[2].y).padding(.all,10)
                    Button(action: {
                        changeviewToApple()
                    }) {
                        Image("apple").resizable().frame(width: 50,height: 50)
                    }.offset(x : list1[3].x,y : list1[3].y).padding(.all,10)
                    Button(action: {
                        changeviewToOrange()
                    }) {
                        Image("Orange").resizable().frame(width: 70,height: 70)
                    }.offset(x : list1[4].x,y : list1[4].y).padding(.all,10)
                        
                    
                    Button(action: {
                        changeviewToOrange()
                    }) {
                        Image("Orange").resizable().frame(width: 70,height: 70)
                    }.offset(x : list1[5].x,y : list1[5].y).padding(.all,10)
                    Button(action: {
                        changeviewToOrange()
                    }) {
                        Image("Orange").resizable().frame(width: 70,height: 70)
                    }.offset(x : list1[6].x,y : list1[6].y).padding(.all,10)
                    
                    Button(action: {
                        changeviewToGrapes()
                    }) {
                        Image("Grapes").resizable().frame(width: 70,height: 70)
                    }.offset(x : list1[7].x,y : list1[7].y).padding(.all,10)
                    Button(action: {
                        changeviewToGrapes()
                    }) {
                        Image("Grapes").resizable().frame(width: 70,height: 70)
                    }.offset(x : list1[8].x,y : list1[8].y).padding(.all,10)
                  
                }
                
               
               
                
                
            }.onAppear(perform: {
                randomnGenerator()
            })
           
            
        }
        else if viewnumber==1{
            AppleView()
        }
        else if viewnumber==2{
            OrangeView()
        }
        else{
            GrapesView()
        }
        
        
        
        
    }
}
