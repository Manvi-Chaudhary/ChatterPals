import SwiftUI

import AVFoundation

struct GrapesView: View {
    @State var ismain = false 
    
    @State var audioPlayer : AVAudioPlayer!
    
    func playSound(){
        let sound = Bundle.main.path(forResource: "grape", ofType: "mp3")
        audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
    } 
    
    func changeview(){
        ismain=true
    }
    var body: some View {
        if !ismain {
            VStack {
                
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                
                
                
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                ZStack {
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.white).shadow(radius: 20)
                    
                    VStack {
                        HStack{
                            
                            Button(action: {
                                changeview()
                            }){
                                Image("Close").padding(.trailing,290)
                            }.padding(.top,30)
                            
                            
                            
                        }
                        
                        Text("Grape").font(.system(size: 44))
                            .foregroundStyle(.black)
                        
                        Image("Grapes").resizable().frame(width: 100,height: 100).scaledToFit().padding(.vertical,30)
                        
                        
                        
                        Button(action: {
                            audioPlayer.play()
                        }){
                            Image("speaker")
                                .font(.system(size: 34, weight: .semibold))
                                .padding(.all,20).background(Color(red:0.5,green:0.5,blue:0.5, opacity:0.5))
                                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/, style: /*@START_MENU_TOKEN@*/FillStyle()/*@END_MENU_TOKEN@*/)
                        }.padding(.vertical,30)
                    }
                    
                    
                        .multilineTextAlignment(.center)
                }.padding(.horizontal,30)
                    .frame(width: 450,height: 400)
                
                
                
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                HStack{
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    Image("image 4").padding(.horizontal,30)
                    
                }.padding(.vertical,10)
                
            }.background(Color(red:0.6,green:0.9,blue:0.3,opacity: 1)).onAppear(perform: {
                playSound()
            })
            
        }
        else {
            ContentView()
        }
      
        
    }
}
